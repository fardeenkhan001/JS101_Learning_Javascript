let a = 1000;
let b = 1000;
if (a>b) {
  console.log("A is Equal");
}
else if(b> a) {
  console.log("B is Greater");
}
else{
  console.log("Both are equal");
}