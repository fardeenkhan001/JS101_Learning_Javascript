let database_username = "abc@gmail.com";
let database_pass = "abc123";

let username = "abc@gmail.com";
let pass = "abc123";

database_username == username && database_pass==pass ? console.log("Login Successfull"):console.log("Invalid Credentials");