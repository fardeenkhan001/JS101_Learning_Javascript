let n  = 10;
if(n%3==0){
  console.log("Number is multiple of 3");
}
else{
  console.log("Number is not a Multiple of 3")
}