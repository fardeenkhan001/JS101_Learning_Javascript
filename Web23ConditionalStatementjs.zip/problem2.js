let age = 17;
if (age >=18){
  console.log("Apply for Licence");
}
else{
  console.log("NA")
}